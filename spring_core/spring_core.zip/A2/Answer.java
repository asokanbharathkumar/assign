package Spring.Core.A2;

import java.util.*;

public class Answer {
	List<String> answerList;
	Set<String> answerSet;
	Map<Integer, String> answerMap;
}